void chprint(char *ch)
{
	printf("%s\n",ch);
}
