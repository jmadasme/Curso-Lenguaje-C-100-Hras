
int datadd(int *list, int max)
{
	int i;
	int sum=0;
	for(i=0; i<max; i++)
		sum += list[i];
		return sum;
}

